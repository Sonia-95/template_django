from django.shortcuts import render

def cadastrar(request):
    return render(request, 'cadastro/pagina_cadastro.html')
